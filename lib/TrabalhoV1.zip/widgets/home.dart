import 'package:flutter/material.dart';
import 'package:interdisciplinar/widgets/fig.dart';
import 'package:interdisciplinar/widgets/user.dart';

class HomePage extends StatefulWidget {
  @override
  State<HomePage> createState() {
    return HomePageState();
  }
}

class HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.white,
              ),
              child: Text('Navegação'),
            ),
            ListTile(
              title: const Text('Usuário'),
              onTap: () {
                debugPrint('Página do usuário');
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => UserPage())
                );
              },
            )
          ],
        ),
      ),
      backgroundColor: const Color.fromARGB(255, 0, 168, 36),
      appBar: AppBar(
        title: const Text('Home Page'),
        backgroundColor: const Color.fromARGB(255, 236, 232, 0),
      ),
      body: BuildListView(),
    );
  }

  BuildListView() {
      return ListView(
        padding: const EdgeInsets.all(8),
        children: <Widget>[
        Container(
          color: const Color.fromARGB(255, 0, 14, 211),
          child: Card(
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () {
                debugPrint('clicou no card');
              },
              child: Column(
                children: const <Widget>[
                  Text('Figurinha Copa 2014'),
                  Text('RS 2,00'),
                  Image(
                    image: NetworkImage('https://http2.mlstatic.com/D_NQ_NP_15131-MLB20097727719_052014-O.webp')),
                ],   
              ),
            )
          )
        ),
        const SizedBox(height: 10),
        Container(
          color: const Color.fromARGB(255, 0, 14, 211),
          child: Card(
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () {
                debugPrint('clicou no card');
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => FigPage())
                );
              },
              child: Column(
                children: const <Widget>[
                  Text('Figurinhas Copa 2018'),
                  Text('RS 9,00'),
                  Image(
                    image: NetworkImage('https://http2.mlstatic.com/D_NQ_NP_848541-MLB27227031969_042018-O.webp')),
                ],   
              ),
            )
          )
        ),
        ],
      );
    }
}