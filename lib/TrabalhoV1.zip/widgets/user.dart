import 'package:flutter/material.dart';

class UserPage extends StatefulWidget {
  @override
  State<UserPage> createState() {
    return UserPageState();
  }
}

class UserPageState extends State<UserPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 0, 168, 36),
      appBar: AppBar(
        title: const Text('Usuário'),
        backgroundColor: const Color.fromARGB(255, 236, 232, 0),
      ),
      body: Center(
        child: Container(
        color: const Color.fromARGB(255, 0, 3, 48),
        child: Card(
          color: const Color.fromARGB(255, 0, 14, 211),
          child: Column(
                children: const <Widget>[
                  Image(
                    image: NetworkImage('https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Breezeicons-actions-22-im-user.svg/1200px-Breezeicons-actions-22-im-user.svg.png')),
                  Text('Nome de usuario: Ciclano'),
                  Text('Contato: 1111-1111'),
                  Text('Email: ciclano123@gmail.com'),
                ],   
              ),
        ),
      )
      ),
    );
  }
}