import 'package:flutter/material.dart';

class FigPage extends StatefulWidget {
  @override
  State<FigPage> createState() {
    return FigPageState();
  }
}

class FigPageState extends State<FigPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 0, 168, 36),
      appBar: AppBar(
        title: const Text('Detalhes'),
        backgroundColor: const Color.fromARGB(255, 236, 232, 0),
      ),
      body: Center(
        child: Container(
        color: const Color.fromARGB(255, 0, 3, 48),
        child: Card(
          color: const Color.fromARGB(255, 0, 14, 211),
          child: Column(
                children: const <Widget>[
                  Image(
                    image: NetworkImage('https://http2.mlstatic.com/D_NQ_NP_848541-MLB27227031969_042018-O.webp')),
                  Text('Preço: RS 9,00'),
                  Text('Conteúdo: 4 figurinhas da Copa de 2018'),
                  Text('Vendedor: Fulano'),
                  Text('Contato: 0000-0000')
                ],   
              ),
        ),
      )
      ),
    );
  }
}