// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:interdisciplinar/widgets/home.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}
class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 0, 168, 36),
      appBar: AppBar(title: const Text("Login"), backgroundColor: const Color.fromARGB(255, 236, 232, 0)),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
               const TextField(
                autofocus: true,
                keyboardType: TextInputType.number,
                style: TextStyle(color: Colors.white, fontSize: 30),
                decoration: InputDecoration(
                  labelText:"Nome do usuário",
                  labelStyle: TextStyle(color: Colors.black),
                )
              ),
              const TextField(
                autofocus: true,
                obscureText: true,
                keyboardType: TextInputType.text,
                style: TextStyle(color: Colors.white, fontSize: 30),
                decoration: InputDecoration(
                  labelText:"Senha do usuário",
                  labelStyle: TextStyle(color: Colors.black),
                )
              ),
              const SizedBox(height: 15),
              ButtonTheme(
                height: 60.0,
                child: RaisedButton(
                  onPressed: () => { debugPrint("clicou no botão"), 
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (context) => HomePage()))
                    },
                  shape: RoundedRectangleBorder(borderRadius:
                  BorderRadius.circular(30.0)),
                  child: const Text(
                    "Enviar",
                    style: TextStyle(color: Colors.white, fontSize: 30),
                  ), //Text
                  color:const Color.fromARGB(255, 0, 14, 211),
                ),//RaisedButton
              ),//ButtonTheme
            ],
         ),
        ),
      )     
    );
  }
}